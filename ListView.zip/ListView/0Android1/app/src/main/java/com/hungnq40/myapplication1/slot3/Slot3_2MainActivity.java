package com.hungnq40.myapplication1.slot3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

public class Slot3_2MainActivity extends AppCompatActivity {
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot32_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //
        tvKQ = findViewById(R.id.slot3_2Tv1);
        //get data from intent
        Intent intent1 = getIntent();
        //extract data
        int a = Integer.parseInt(intent1.getExtras().getString("hsa"));
        int b = Integer.parseInt(intent1.getExtras().getString("hsb"));
        int c = Integer.parseInt(intent1.getExtras().getString("hsc"));
        //delta=?
        double delta= b*b-4*a*c;
        if(delta<0){
            tvKQ.setText("PTVN");
        }
        else if (delta==0){
            tvKQ.setText("PT co nghiem kep x="+(-b)/(2*a));
        }
        else {
            double x1 = ((-b)+Math.sqrt(delta))/(2*a);
            double x2 = ((-b)-Math.sqrt(delta))/(2*a);
            tvKQ.setText("PT co 2 nghiem x1 = "+x1+"; va x2="+x2);
        }
    }
}