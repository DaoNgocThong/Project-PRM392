package com.hungnq40.myapplication1.slot3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

public class SLot3_1MainActivity extends AppCompatActivity {
    //giai phuong trinh bac 2
    EditText txt1,txt2,txt3;
    Button btn1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot31_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa
        txt1 = findViewById(R.id.slot3_1Txt1);
        txt2 = findViewById(R.id.slot3_1Txt2);
        txt3 = findViewById(R.id.slot3_1Txt3);
        btn1  =findViewById(R.id.slot3_1Btn1);
        //xu lys su kien
        btn1.setOnClickListener(v->{
            sendData();
        });
    }

    private void sendData() {
        //get data from input user
        String a= txt1.getText().toString();
        String b = txt2.getText().toString();
        String c = txt3.getText().toString();
        //create intent
        Intent intent = new Intent(SLot3_1MainActivity.this, Slot3_2MainActivity.class);
        //put data to intent
        intent.putExtra("hsa",a);
        intent.putExtra("hsb",b);
        intent.putExtra("hsc",c);
        //start activity
        startActivity(intent);
    }
}