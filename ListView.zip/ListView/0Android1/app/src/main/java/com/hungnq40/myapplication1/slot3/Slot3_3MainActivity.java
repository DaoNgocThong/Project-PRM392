package com.hungnq40.myapplication1.slot3;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

public class Slot3_3MainActivity extends AppCompatActivity {
    ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot33_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView = findViewById(R.id.slot3_3Lv);
        getDataToListView();
    }

    private void getDataToListView() {
        //Create data source
        String[] arr = new String[]{
               "lap trinh java",
               "lap trinh android","lap trinh react native",".net","php"
        };
        //using adapter
        //arrayAdapter co 3 tham so: context, layout, datasource
        ArrayAdapter<String> adapter = new ArrayAdapter<>(Slot3_3MainActivity.this,
                android.R.layout.simple_list_item_1,arr);
        //attach adapter to listview
        listView.setAdapter(adapter);
    }
}